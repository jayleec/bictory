int a[10];
