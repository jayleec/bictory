#include "MIS14_A.h"		/* Forbidden header file is included */
#include "MIS14_B.h"		/* Forbidden header file is included */

void testFunc() {
	return;
}