// @checker INCONSISTENT_GLOBAL_VARIABLE_TYPE

extern int * a; // @violation INCONSISTENT_GLOBAL_VARIABLE_TYPE

// Do something...

void Func(const char * x, const char * y) {	
	// Do something ...
}

