// @checker BAD_QUALIFIER.REQUIRED.PARAM_PTR

void Func(char * a, int b) { // @violation BAD_QUALIFIER.REQUIRED.PARAM_PTR
	// Do something 
}
