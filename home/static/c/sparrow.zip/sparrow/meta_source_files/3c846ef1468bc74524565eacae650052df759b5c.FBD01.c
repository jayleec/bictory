void badFoo(int abc) {
    badLabel: {    /* Violation : Forbidden label Statement */
        /* do something */
    }
}   

void goodFoo(int abc) {
    /* do something */
    
}   
