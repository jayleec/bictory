void good1st() {

}

void good2nd() {
   
}

void bad3rd() {			/* Violation: The number of maximum allowed functions is 2 */
   
}