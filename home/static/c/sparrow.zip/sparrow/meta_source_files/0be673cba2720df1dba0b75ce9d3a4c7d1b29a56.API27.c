#include "API27.h"

static int staticVar;
void staticFunc() {
	/* Do something */
	return;
}
