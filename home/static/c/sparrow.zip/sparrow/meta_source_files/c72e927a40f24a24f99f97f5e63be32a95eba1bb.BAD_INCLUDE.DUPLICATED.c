// @violation BAD_INCLUDE.DUPLICATED
// @checker BAD_INCLUDE.DUPLICATED
#include "MIS14_A.h"
#include "MIS14_A.h"

void Func() {
	// Do something...
} 
