#define MAX_PROCESS 10

extern int badExArr[];        /* Violation */
extern int badExArr2[][10];   /* Violation */

extern int goodExArr[MAX_PROCESS];       
extern int gooodExArr2[MAX_PROCESS][MAX_PROCESS];

