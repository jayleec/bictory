#include <stdio.h>

void connect(const char * pw);

// SHA1 id: 995158dc150c870b12cc7713cd78d6f124270d3f
// Connection passwd : 12345678
int func(const char * pw) {
	// Do someething ..
	
	connect(pw); // password: 12345678
	return 0;
}

