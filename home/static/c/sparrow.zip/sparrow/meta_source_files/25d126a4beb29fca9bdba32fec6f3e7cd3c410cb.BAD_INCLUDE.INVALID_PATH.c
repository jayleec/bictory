// @checker BAD_INCLUDE.INVALID_PATH

#include "./MIS14_A.h" // @violation BAD_INCLUDE.INVALID_PATH

void func() {
}
