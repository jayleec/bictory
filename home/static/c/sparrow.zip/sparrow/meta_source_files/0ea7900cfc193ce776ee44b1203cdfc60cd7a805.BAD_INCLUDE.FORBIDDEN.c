// @checker BAD_INCLUDE.FORBIDDEN

#include "MIS14_A.h" // @violation BAD_INCLUDE.FORBIDDEN
#include "MIS14_B.h" // @violation BAD_INCLUDE.FORBIDDEN

void func() {
}
