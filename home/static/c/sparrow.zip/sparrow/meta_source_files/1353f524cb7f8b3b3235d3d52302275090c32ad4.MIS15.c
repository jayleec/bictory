#include "MIS15_A.h"
#include "./MIS15_B.h"		/* Violation */

void func() {
	/* do something */
}