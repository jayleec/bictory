//#include "MIS16_A.h"		/* Required header file is missing */
#include "MIS16_B.h"		/* Required header file is missing */

void testFunc() {
	return;
}