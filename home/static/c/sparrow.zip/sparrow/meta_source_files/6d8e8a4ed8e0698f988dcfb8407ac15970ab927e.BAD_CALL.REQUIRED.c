// @violation BAD_CALL.REQUIRED
// @checker BAD_CALL.REQUIRED

void Func() {
	// Do something ..
}
