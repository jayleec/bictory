//#include "MIS16_A.h"		/* Required header file is missing */
#include "e77254c6618aeea08af9a86d02bf05b60cf5db75.MIS16_B.h"		/* Required header file is missing */

void testFunc() {
	return;
}
