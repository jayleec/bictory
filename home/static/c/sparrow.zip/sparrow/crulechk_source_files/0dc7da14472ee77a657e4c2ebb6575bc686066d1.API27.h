// API27 Header file

static int staticHeaderVar; 	            /*  Violation   */
static void staticFunc();			        /*  Violation   */