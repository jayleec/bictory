// @violation BAD_INCLUDE.DUPLICATED
// @checker BAD_INCLUDE.DUPLICATED
#include "da39a3ee5e6b4b0d3255bfef95601890afd80709.MIS14_A.h"
#include "da39a3ee5e6b4b0d3255bfef95601890afd80709.MIS14_A.h"

void Func() {
	// Do something...
} 
