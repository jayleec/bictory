void goodHeaderFunc(void) {
	/* do something */
}