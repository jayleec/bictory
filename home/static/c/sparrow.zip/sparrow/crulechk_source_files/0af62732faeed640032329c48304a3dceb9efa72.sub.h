#ifndef _SUB_H_
#define _SUB_H_

int sum(int a, int b);
int substract(int a, int b);
double divide(int a, int b);
long multiply(int a, int b);

#endif //	_SUB_H_