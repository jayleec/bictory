// MIS15_B Header

void testFunc_B() {
	return;
}