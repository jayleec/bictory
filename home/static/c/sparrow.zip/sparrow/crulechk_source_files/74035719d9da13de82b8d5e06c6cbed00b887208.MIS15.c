#include "59706793cb248d9b549b5e54e273e443284cf66c.MIS15_A.h"
#include "a2c33e1bda6a94cc45200e5404bedb4f890ce8f5.MIS15_B.h"		/* Violation */

void func() {
	/* do something */
}
