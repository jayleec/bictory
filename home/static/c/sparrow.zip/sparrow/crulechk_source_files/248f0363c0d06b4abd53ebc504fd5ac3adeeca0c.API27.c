#include "0dc7da14472ee77a657e4c2ebb6575bc686066d1.API27.h"

static int staticVar;
void staticFunc() {
	/* Do something */
	return;
}
