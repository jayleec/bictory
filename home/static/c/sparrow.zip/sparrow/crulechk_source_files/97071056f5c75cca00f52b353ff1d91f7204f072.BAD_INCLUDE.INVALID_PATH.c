// @checker BAD_INCLUDE.INVALID_PATH

#include "da39a3ee5e6b4b0d3255bfef95601890afd80709.MIS14_A.h" // @violation BAD_INCLUDE.INVALID_PATH

void func() {
}
